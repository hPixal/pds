function closegnup;

__gnuplot_raw__("clear;\n");
__gnuplot_raw__("set reset;\n");
